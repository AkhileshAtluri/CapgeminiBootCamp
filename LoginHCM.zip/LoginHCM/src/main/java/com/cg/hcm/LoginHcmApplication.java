package com.cg.hcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginHcmApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginHcmApplication.class, args);
	}

}
