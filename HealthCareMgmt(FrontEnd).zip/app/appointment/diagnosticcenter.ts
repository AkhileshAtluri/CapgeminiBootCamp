export class DiagnosticCenter
{
	centerId:number;
	centerName:String;
	area:String;
	public constructor(centerId:number, centerName:String, area:String)
	{
		this.centerId = centerId;
		this.centerName = centerName;
		this.area = area;
	}
}