import { NgModule } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { AppointmentHomeComponent } from './appointmenthome-component';
import { AddAppointmentComponent } from './addappointment-component';
import { DisplayAppointmentComponent } from './displayappointment-component';
import { DeleteAppointmentComponent } from './deleteappointment-component';
import { AppointmentsComponent } from './appointments-component';

const routes: Routes = [
                        {path:'',component:AppointmentHomeComponent,children:[
		  {path:'',children:[
			{path:'addappointment',component:AddAppointmentComponent},
                        {path:'displayappointment',component:DisplayAppointmentComponent},
                        {path:'deleteappointment',component:DeleteAppointmentComponent},
			{path:'allappointments',component:AppointmentsComponent}

]}]}
                       ];


@NgModule({

  imports: [RouterModule.forChild(routes)],

  exports: [RouterModule]

})

export class AppointmentRoutingModule 
{ }
