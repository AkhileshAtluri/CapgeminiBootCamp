import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms'; 
import { CommonModule } from '@angular/common';
import { AppointmentRoutingModule } from './appointment-routing.module';
import { AppointmentService } from './appointment-service';
import { AppointmentHomeComponent } from './appointmenthome-component';
import { AddAppointmentComponent } from './addappointment-component';
import { DisplayAppointmentComponent } from './displayappointment-component';
import { DeleteAppointmentComponent } from './deleteappointment-component';
import { AppointmentsComponent } from './appointments-component';


@NgModule({
  
   declarations: [
    AppointmentHomeComponent, AddAppointmentComponent, 
                     DisplayAppointmentComponent, DeleteAppointmentComponent, AppointmentsComponent  ],
 
   imports: [
    HttpClientModule, FormsModule , CommonModule, AppointmentRoutingModule],
  
   providers: [ AppointmentService ],
 
   exports: [ AppointmentHomeComponent, AddAppointmentComponent, DisplayAppointmentComponent,
		 DeleteAppointmentComponent, AppointmentsComponent ]
})
export class AppointmentModule
{
}