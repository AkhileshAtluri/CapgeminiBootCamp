export class Test
{
	testId:number;
	testName:String;
	description:String;
	price:number;
	public constructor(testId:number, testName:String, description:String, price:number)
	{
		this.testId = testId;
		this.testName = testName;
		this.description = description;
		this.price = price;
	}
}