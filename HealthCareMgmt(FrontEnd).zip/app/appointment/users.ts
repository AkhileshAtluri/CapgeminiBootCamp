export class Users
{
	userId:number;
	userName:String;
	password:String;
	emailId:String;
	gender:String;
	age:number;
	role:String;
	public constructor(userId:number, userName:String, password:String, emailId:String, gender:String, age:number, role:String)
	{
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.emailId = emailId;
		this.gender = gender;
		this.age = age;
		this.role = role;
	}
}