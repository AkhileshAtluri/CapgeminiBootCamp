import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment } from './appointment';
import { Test } from './test';
import { DiagnosticCenter } from './diagnosticcenter';
import { Users } from './users';
import { AppointmentService } from './appointment-service';


@Component
({
	selector : 'deleteappointment',
	templateUrl : './deleteappointment-component.html'
})
export class DeleteAppointmentComponent implements OnInit
{
	test2 : Test = new Test(0,"","",0);
	diagnosticCenter2 : DiagnosticCenter = new DiagnosticCenter(0,"","");
	user2 : Users = new Users(0,"","","","",0,"");
	appointment : Appointment = new Appointment(0,"","",this.test2,this.diagnosticCenter2,this.user2);
	public constructor(private appointmentService : AppointmentService, private router : Router){}
	public deleteAppointment() : void
        {
    		if(confirm("Are You Sure?"))
		{
    	    		this.appointmentService.deleteAppointment(this.appointment.appointmentId).subscribe();
	    		alert("Appointment Deleted");
	    		this.router.navigate(['/home/appointmentsop']);
		}
       }
	
	ngOnInit(){}
}