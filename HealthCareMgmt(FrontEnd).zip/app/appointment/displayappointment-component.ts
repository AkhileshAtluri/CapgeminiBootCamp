import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment } from './appointment';
import { Test } from './test';
import { DiagnosticCenter } from './diagnosticcenter';
import { Users } from './users';
import { AppointmentService } from './appointment-service';


@Component
({
	selector : 'displayappointment',
	templateUrl : './displayappointment-component.html'
})
export class DisplayAppointmentComponent implements OnInit
{
	flag : Boolean = false;
	test3 : Test = new Test(0,"","",0);
	diagnosticCenter3 : DiagnosticCenter = new DiagnosticCenter(0,"","");
	user3 : Users = new Users(0,"","","","",0,"");
	appointment : Appointment = new Appointment(0,"","",this.test3,this.diagnosticCenter3,this.user3);
	public constructor(private appointmentService : AppointmentService, private router : Router){}
	 public getAppointment():void
    {
	this.appointmentService.getAppointment(this.appointment.appointmentId).subscribe(data => this.appointment = data );
        this.flag = true;
    }

    ngOnInit(){}
}
