import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Appointment } from './appointment';
import { Test } from './test';
import { DiagnosticCenter } from './diagnosticcenter';
import { Users } from './users';
import { AppointmentService } from './appointment-service';


@Component
({
	selector : 'addappointment',
	templateUrl : './addappointment-component.html'
})
export class AddAppointmentComponent implements OnInit
{
	test : Test = new Test(0,"","",0);
	diagnosticCenter : DiagnosticCenter = new DiagnosticCenter(0,"","");
	user : Users = new Users(0,"","","","",0,"");
	appointment : Appointment = new Appointment(0,"","",this.test,this.diagnosticCenter,this.user);
	public constructor(private appointmentService : AppointmentService, private router : Router){}
	public addAppointment() : void
    	{
		this.appointmentService.addAppointment(this.appointment).subscribe();
		alert("Appointment Made Successfully");
		this.router.navigate(['/home/appointmentsop']);
        }
    	ngOnInit(){}	
}
