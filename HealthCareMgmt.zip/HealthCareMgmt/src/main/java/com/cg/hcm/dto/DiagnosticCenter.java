package com.cg.hcm.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity											 // Indicates bean class that is mapped with DataBase table
@Table(name="diagnostic_center")					 // Table name in Database

public class DiagnosticCenter 
{
	@Id										     // Indicates the field associated with it is a primary key in DataBase table
	@Column(name="center_id")					// Indicates the column name in the DataBase table
	int centerId;
	@Column(name="center_name")
	String centerName;
	@Column(name="area")
	String area;
	public DiagnosticCenter(){}
	public DiagnosticCenter(int centerId, String centerName, String area) {
		super();
		this.centerId = centerId;
		this.centerName = centerName;
		this.area = area;
	}
	public int getCenterId() {
		return centerId;
	}
	public void setCenterId(int centerId) {
		this.centerId = centerId;
	}
	public String getCenterName() {
		return centerName;
	}
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	
}
