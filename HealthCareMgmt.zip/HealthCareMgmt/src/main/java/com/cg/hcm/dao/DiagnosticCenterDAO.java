package com.cg.hcm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.hcm.dto.DiagnosticCenter;

public interface DiagnosticCenterDAO extends JpaRepository<DiagnosticCenter, Integer>
{

}
