package com.cg.hcm.dto;

public class Tests {

}
