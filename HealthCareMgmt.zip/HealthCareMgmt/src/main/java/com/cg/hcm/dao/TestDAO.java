package com.cg.hcm.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.hcm.dto.Test;

public interface TestDAO extends JpaRepository<Test, Integer>
{

}
