package com.cg.hcm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hcm.dao.DiagnosticCenterDAO;
import com.cg.hcm.dto.DiagnosticCenter;

@Service 
public class DiagnosticCenterService 
{
	@Autowired
	DiagnosticCenterDAO dcdao;

	public void setDcdao(DiagnosticCenterDAO dcdao) {
		this.dcdao = dcdao;
	}
	
	public List<DiagnosticCenter> getAllCenters()
	{
		return dcdao.findAll();
	}
}
