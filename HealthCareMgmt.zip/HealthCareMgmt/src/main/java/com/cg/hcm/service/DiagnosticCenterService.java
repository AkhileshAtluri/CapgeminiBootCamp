package com.cg.hcm.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hcm.dao.DiagnosticCenterDAO;
import com.cg.hcm.dto.DiagnosticCenter;

@Service 
public class DiagnosticCenterService 
{
	@Autowired
	DiagnosticCenterDAO dcdao;

	public void setDcdao(DiagnosticCenterDAO dcdao) {
		this.dcdao = dcdao;
	}
	
    @Transactional
    //inserting data into database
    public DiagnosticCenter insertDiagnosticcenter( DiagnosticCenter  diagnosticcenter)
    {
        return dcdao.save( diagnosticcenter);
    }
	
    @Transactional
    //deleting data from database
    public String deleteDiagnosticcenter(int centerId)
    {
    	dcdao.deleteById(centerId);
    	return "center Deleted";
    }
   
    @Transactional
    public Optional<DiagnosticCenter> getDiagnosticcenter(int centerId)
    {
    	return dcdao.findById(centerId);
    }

	@Transactional
	public List<DiagnosticCenter> getAllCenters()
	{
		return dcdao.findAll();
	}
}



