package com.cg.hcm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hcm.dao.TestDAO;
import com.cg.hcm.dto.Test;

@Service
public class TestService 
{
	@Autowired
	TestDAO tdao;

	public void setTdao(TestDAO tdao) {
		this.tdao = tdao;
	}
	
	public List<Test> getAllTests()
	{
		return tdao.findAll();
	}
	
}
