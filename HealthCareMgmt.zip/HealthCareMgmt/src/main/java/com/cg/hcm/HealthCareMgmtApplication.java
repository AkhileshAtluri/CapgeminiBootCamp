package com.cg.hcm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthCareMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthCareMgmtApplication.class, args);
	}

}
