package com.cg.hcm.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity											 // Indicates bean class that is mapped with DataBase table
@Table(name="appointment")					    // Table name in Database

public class Appointment 
{
	@Id											// Indicates the field associated with it is a primary key in DB
	@Column(name="appointment_id")								// Indicates the column name in the DataBase table
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="MYSEQ")
	@SequenceGenerator(name="MYSEQ",sequenceName = "appointment_id",allocationSize=1)
	int appointmentId;
	@Column(name="status")
	String status;
	@Column(name="appointment_date")
	LocalDate date;
	@OneToOne									// Relationship between two classes
	@JoinColumn(name="test_id")					// foreign key reference in DB table
	Test test;
	@OneToOne									
	@JoinColumn(name="center_id")				
	DiagnosticCenter diagnosticCenter;
	@OneToOne
	@JoinColumn(name="user_id")
	Users user;
	public Appointment(){} 					// Default constructor
	public Appointment(int appointmentId, String status, LocalDate date, Test test, DiagnosticCenter diagnosticCenter,Users user) {
		super();
		this.appointmentId = appointmentId;
		this.status = status;
		this.date = date;
		this.test = test;
		this.diagnosticCenter = diagnosticCenter;
		this.user = user;
	}
	public int getAppointmentId() {
		return appointmentId;
	}
	public void setAppointmentId(int appointmentId) {
		this.appointmentId = appointmentId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public Test getTest() {
		return test;
	}
	public void setTest(Test test) {
		this.test = test;
	}
	public DiagnosticCenter getDiagnosticCenter() {
		return diagnosticCenter;
	}
	public void setDiagnosticCenter(DiagnosticCenter diagnosticCenter) {
		this.diagnosticCenter = diagnosticCenter;
	}
	public Users getUser() {
		return user;
	}
	public void setUser(Users user) {
		this.user = user;
	}
	
	
	
}
