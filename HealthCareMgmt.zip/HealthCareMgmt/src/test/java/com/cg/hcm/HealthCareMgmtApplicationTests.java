package com.cg.hcm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HealthCareMgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
