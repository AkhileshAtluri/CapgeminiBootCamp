package com.cg.hcm.service;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.cg.hcm.dto.Appointment;

@SpringBootTest
public class TestAppointmentService 
{
	@Autowired																// Injects dependencies automatically
	AppointmentService aps;
	
	@Test																	// Indicates method is a test method 
	public void testGetAppointment_positve() throws Exception
	{
		Optional<Appointment> appt = aps.getAppointment(1);
		Assertions.assertEquals(true, appt.isPresent());
	}

	@Test
	public void testGetAppointment_negative() throws Exception
	{
		Optional<Appointment> appt = aps.getAppointment(1000);
		Assertions.assertEquals(false, appt.isPresent());
	}
	
	@Test
	public void testDeleteAppointment_Positive() throws Exception
	{
		String s = aps.deleteAppointment(100);
		Assertions.assertEquals("Deleted Successfully", s);
	}
	
	@Test
	public void testDeleteAppointment_Negative() throws Exception
	{
		String s = aps.deleteAppointment(1000);
		Assertions.assertEquals("Deleted Successfully", s);
	}
}
