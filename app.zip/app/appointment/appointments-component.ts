import { Component, OnInit } from '@angular/core';
import { AppointmentService } from './appointment-service';
import { Appointment } from './appointment';
@Component({
	selector : 'appointments',
	templateUrl : './appointments-component.html'
})
export class AppointmentsComponent implements OnInit
{
    flag:Boolean = false;
    appt : Appointment[] = [];
 
    public constructor(private appointmentService : AppointmentService){}
    
    public getAllAppointments() : void
	{
	    this.appointmentService.getAllAppointments().subscribe(data => {this.appt = data;console.log(data)});
	    this.flag = true;
        } 

    ngOnInit(){}
}