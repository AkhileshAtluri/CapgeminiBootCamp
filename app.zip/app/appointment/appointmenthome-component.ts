import { Component, OnInit } from '@angular/core';
@Component
({
	selector : 'appointmenthome',
	templateUrl : './appointmenthome-component.html'
})
export class AppointmentHomeComponent implements OnInit
{
    ngOnInit(){}
}