export class Users
{
	userId:number;
	password:String;
	userName:String;
	emailId:String;
	gender:String;
	age:number;
	public constructor(userId:number, password:String, userName:String, emailId:String, gender:String, age:number)
	{
		this.userId = userId;
		this.password = password;
		this.userName = userName;
		this.emailId = emailId;
		this.gender = gender;
		this.age = age;
	}
}