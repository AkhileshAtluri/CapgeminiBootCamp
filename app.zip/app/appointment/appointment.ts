import { Test } from './test';
import { DiagnosticCenter } from './diagnosticcenter';
import { Users } from './users';

export  class Appointment
{
	appointmentId:number;
	status:String;
	date:String;
	test:Test = new Test(0,"","",0);
	diagnosticCenter:DiagnosticCenter = new DiagnosticCenter(0,"","");
	user:Users = new Users(0,"","","","",0);
	public constructor(appointmentId:number, status:String, date:String,test:Test, diagnosticCenter:DiagnosticCenter, user:Users)
	{
		this.appointmentId = appointmentId;
		this.status = status;
		this.date = date;
		this.test = test;
		this.diagnosticCenter = diagnosticCenter;
		this.user = user;

	}
}