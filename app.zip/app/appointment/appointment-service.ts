import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Appointment } from './appointment';

@Injectable({
	providedIn:'root'
})
export class AppointmentService
{
	public constructor(private httpClient:HttpClient){}

	public getAppointment(appointmentId:number) : Observable<Appointment>
	{
		return this.httpClient.get<any>('http://localhost:8615/getAppointment/'+appointmentId);
	}
	
	public getAllAppointments() : Observable<Appointment[]>
	{
		return this.httpClient.get<Appointment[]>('http://localhost:8615/getAllAppointments');
	}
	
	public deleteAppointment(appointmentId:number) : any
	{
		return this.httpClient.delete<any>('http://localhost:8615/deleteAppointment'+appointmentId);
	}

	public addAppointment(appointment:Appointment) : any
	{
		return this.httpClient.post<any>('http://localhost:8615/addAppointment',appointment);
	}
}