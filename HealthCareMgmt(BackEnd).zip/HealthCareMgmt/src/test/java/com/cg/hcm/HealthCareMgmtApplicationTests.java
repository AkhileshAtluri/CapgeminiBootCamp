package com.cg.hcm;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import com.cg.hcm.dto.Appointment;

@SpringBootTest
class HealthCareMgmtApplicationTests {

	@Test
	void contextLoads(){
	}
	
	@Autowired																// Injects dependencies automatically
	TestRestTemplate testrt;

	public void setTestrt(TestRestTemplate testrt) {
		this.testrt = testrt;
	}
	
	@LocalServerPort														// HTTP port allocated at runtime
	int localps;
	
	@Test																	// Indicates method is a test method
	void testGetAppointment_Positive() throws Exception					   // method to test Get Appointment (Positive case)
	{
		String url = "http://localhost:"+localps+"getAppointment/1";
		ResponseEntity<Appointment> appt = testrt.getForEntity(url, Appointment.class);
		Assertions.assertEquals(200,appt.getStatusCode()); 
	}

	@Test
	void testGetAppointment_Negative() throws Exception						// method to test Get Appointment (Negative case)
	{
		String url = "http://localhost:"+localps+"getAppointment/111";
		ResponseEntity<Appointment> appt = testrt.getForEntity(url, Appointment.class);
		Assertions.assertEquals(404,appt.getStatusCode());
	}
	
	@Test
	void testDeleteAppointment_Positve() throws Exception						// method to test Delete Appointment (Positive case)
	{
		String url = "http://localhost:"+localps+"deleteAppointment/111";
		ResponseEntity<String> res = testrt.exchange(url,HttpMethod.DELETE,null,String.class);
		Assertions.assertEquals(200,res.getStatusCode());
	}
	
	@Test
	void testDeleteAppointment_Negative() throws Exception						// method to test Delete Appointment (Negative case)
	{
		String url = "http://localhost:"+localps+"deleteAppointment/1";
		ResponseEntity<String> res = testrt.exchange(url,HttpMethod.DELETE,null,String.class);
		Assertions.assertEquals(404,res.getStatusCode());
	}
}
