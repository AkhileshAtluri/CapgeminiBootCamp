package com.cg.hcm.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity										// Indicates bean class that is mapped with DataBase table
@Table(name="test")							// Table name in Database
public class Test 
{
	@Id										// Indicates the field associated with it is a primary key in DataBase table
	@Column(name="test_id")					// Indicates the column name in the DataBase table
	int testId;
	@Column(name="test_name")
	String testName;
	@Column(name="description")
	String description;
	@Column(name="price")
	int price;
	public Test(){}
	public Test(int testId, String testName, String description, int price) {
		super();
		this.testId = testId;
		this.testName = testName;
		this.description = description;
		this.price = price;
	}
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
